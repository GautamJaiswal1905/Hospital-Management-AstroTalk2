package com.Hospital.payload;

import lombok.Data;

@Data
public class DischargeDto {
    private String status="Discharged";
}
